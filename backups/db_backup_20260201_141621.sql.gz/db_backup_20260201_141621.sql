--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8
-- Dumped by pg_dump version 15.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: hamroh_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO hamroh_user;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: hamroh_user
--

COMMENT ON SCHEMA public IS '';


--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: hamroh_user
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO hamroh_user;

--
-- Name: tiger_data; Type: SCHEMA; Schema: -; Owner: hamroh_user
--

CREATE SCHEMA tiger_data;


ALTER SCHEMA tiger_data OWNER TO hamroh_user;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: hamroh_user
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO hamroh_user;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: hamroh_user
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: feedback_status_enum; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.feedback_status_enum AS ENUM (
    'OPEN',
    'IN_PROGRESS',
    'RESOLVED',
    'IGNORED'
);


ALTER TYPE public.feedback_status_enum OWNER TO hamroh_user;

--
-- Name: feedback_type_enum; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.feedback_type_enum AS ENUM (
    'COMPLAINT',
    'SUGGESTION'
);


ALTER TYPE public.feedback_type_enum OWNER TO hamroh_user;

--
-- Name: gender_enum; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.gender_enum AS ENUM (
    'MALE',
    'FEMALE'
);


ALTER TYPE public.gender_enum OWNER TO hamroh_user;

--
-- Name: order_status; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.order_status AS ENUM (
    'PENDING',
    'ACCEPTED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public.order_status OWNER TO hamroh_user;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public.transaction_status OWNER TO hamroh_user;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.transaction_type AS ENUM (
    'DEPOSIT',
    'WITHDRAWAL',
    'COMMISSION'
);


ALTER TYPE public.transaction_type OWNER TO hamroh_user;

--
-- Name: trip_status; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.trip_status AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public.trip_status OWNER TO hamroh_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: hamroh_user
--

CREATE TYPE public.user_role AS ENUM (
    'GLAVNI_ADMIN',
    'ADMIN',
    'DRIVER',
    'PASSENGER'
);


ALTER TYPE public.user_role OWNER TO hamroh_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: drivers; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.drivers (
    driver_id bigint NOT NULL,
    user_id bigint NOT NULL,
    full_name character varying(255) NOT NULL,
    phone_number character varying(20) NOT NULL,
    car_model character varying(100) NOT NULL,
    car_color character varying(50) NOT NULL,
    car_number character varying(20) NOT NULL,
    license_number character varying(50),
    balance numeric(10,2) NOT NULL,
    total_trips integer NOT NULL,
    rating numeric(3,2) NOT NULL,
    ban_count_today integer NOT NULL,
    total_ban_count integer NOT NULL,
    is_active boolean NOT NULL,
    is_on_trip boolean NOT NULL,
    is_blocked boolean NOT NULL,
    blocked_until timestamp with time zone,
    block_reason character varying(255),
    current_route_id integer,
    available_seats integer NOT NULL,
    last_location_lat numeric(10,8),
    last_location_lon numeric(11,8),
    location public.geometry(Point,4326),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    last_trip_at timestamp with time zone,
    CONSTRAINT check_balance_positive CHECK ((balance >= (0)::numeric)),
    CONSTRAINT check_rating_range CHECK (((rating >= 1.00) AND (rating <= 5.00))),
    CONSTRAINT check_seats_range CHECK (((available_seats >= 0) AND (available_seats <= 6)))
);


ALTER TABLE public.drivers OWNER TO hamroh_user;

--
-- Name: COLUMN drivers.driver_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.driver_id IS 'Driver ID (auto increment)';


--
-- Name: COLUMN drivers.user_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.user_id IS 'User ID (Telegram)';


--
-- Name: COLUMN drivers.full_name; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.full_name IS 'To''liq ism';


--
-- Name: COLUMN drivers.phone_number; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.phone_number IS 'Telefon raqam (+998901234567)';


--
-- Name: COLUMN drivers.car_model; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.car_model IS 'Mashina markasi (Nexia, Cobalt, etc)';


--
-- Name: COLUMN drivers.car_color; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.car_color IS 'Mashina rangi';


--
-- Name: COLUMN drivers.car_number; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.car_number IS 'Mashina raqami (01 A 123 BC)';


--
-- Name: COLUMN drivers.license_number; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.license_number IS 'Haydovchilik guvohnomasi';


--
-- Name: COLUMN drivers.balance; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.balance IS 'Balans (so''m)';


--
-- Name: COLUMN drivers.total_trips; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.total_trips IS 'Jami safarlar soni';


--
-- Name: COLUMN drivers.rating; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.rating IS 'Reyting (1.00 - 5.00)';


--
-- Name: COLUMN drivers.ban_count_today; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.ban_count_today IS 'Bugungi ban soni';


--
-- Name: COLUMN drivers.total_ban_count; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.total_ban_count IS 'Jami ban soni';


--
-- Name: COLUMN drivers.is_active; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.is_active IS 'Aktiv (online)';


--
-- Name: COLUMN drivers.is_on_trip; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.is_on_trip IS 'Safardaligi';


--
-- Name: COLUMN drivers.is_blocked; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.is_blocked IS 'Bloklangan';


--
-- Name: COLUMN drivers.blocked_until; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.blocked_until IS 'Qachongacha bloklangan';


--
-- Name: COLUMN drivers.block_reason; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.block_reason IS 'Bloklash sababi';


--
-- Name: COLUMN drivers.current_route_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.current_route_id IS 'Hozirgi marshrut';


--
-- Name: COLUMN drivers.available_seats; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.available_seats IS 'Bo''sh o''rinlar soni (0-6)';


--
-- Name: COLUMN drivers.last_location_lat; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.last_location_lat IS 'Oxirgi lokatsiya - Latitude';


--
-- Name: COLUMN drivers.last_location_lon; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.last_location_lon IS 'Oxirgi lokatsiya - Longitude';


--
-- Name: COLUMN drivers.location; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.location IS 'Lokatsiya (PostGIS geometry)';


--
-- Name: COLUMN drivers.created_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.created_at IS 'Yaratilgan sana';


--
-- Name: COLUMN drivers.updated_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.updated_at IS 'Yangilangan sana';


--
-- Name: COLUMN drivers.last_trip_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.drivers.last_trip_at IS 'Oxirgi safar vaqti';


--
-- Name: drivers_driver_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.drivers_driver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.drivers_driver_id_seq OWNER TO hamroh_user;

--
-- Name: drivers_driver_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.drivers_driver_id_seq OWNED BY public.drivers.driver_id;


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.feedbacks (
    feedback_id bigint NOT NULL,
    user_id bigint NOT NULL,
    resolved_by bigint,
    message text NOT NULL,
    type public.feedback_type_enum NOT NULL,
    status public.feedback_status_enum NOT NULL,
    admin_reply text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    resolved_at timestamp with time zone
);


ALTER TABLE public.feedbacks OWNER TO hamroh_user;

--
-- Name: COLUMN feedbacks.resolved_by; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.feedbacks.resolved_by IS 'Kim tomonidan hal qilindi (Admin ID)';


--
-- Name: feedbacks_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.feedbacks_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feedbacks_feedback_id_seq OWNER TO hamroh_user;

--
-- Name: feedbacks_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.feedbacks_feedback_id_seq OWNED BY public.feedbacks.feedback_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    passenger_id bigint NOT NULL,
    driver_id bigint,
    route_id integer NOT NULL,
    trip_id integer,
    pickup_location text NOT NULL,
    pickup_lat numeric(10,8),
    pickup_lon numeric(11,8),
    passenger_count integer NOT NULL,
    has_luggage boolean NOT NULL,
    luggage_count integer NOT NULL,
    luggage_description text,
    status public.order_status NOT NULL,
    commission_amount numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    accepted_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    cancellation_reason character varying(255),
    idempotency_key character varying(255),
    auto_confirmed boolean NOT NULL,
    driver_arrived boolean NOT NULL,
    CONSTRAINT check_luggage_count CHECK ((luggage_count >= 0)),
    CONSTRAINT check_passenger_count CHECK ((((has_luggage = true) AND (passenger_count = 0)) OR ((has_luggage = false) AND (passenger_count >= 1) AND (passenger_count <= 4))))
);


ALTER TABLE public.orders OWNER TO hamroh_user;

--
-- Name: COLUMN orders.order_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.order_id IS 'Buyurtma ID';


--
-- Name: COLUMN orders.passenger_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.passenger_id IS 'Yo''lovchi ID';


--
-- Name: COLUMN orders.driver_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.driver_id IS 'Haydovchi ID (NULL = topilmagan)';


--
-- Name: COLUMN orders.route_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.route_id IS 'Marshrut ID';


--
-- Name: COLUMN orders.trip_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.trip_id IS 'Trip ID (NULL = trip yo''q)';


--
-- Name: COLUMN orders.pickup_location; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.pickup_location IS 'Olish joyi (matn)';


--
-- Name: COLUMN orders.pickup_lat; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.pickup_lat IS 'Olish joyi - Latitude (None for text-only)';


--
-- Name: COLUMN orders.pickup_lon; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.pickup_lon IS 'Olish joyi - Longitude (None for text-only)';


--
-- Name: COLUMN orders.passenger_count; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.passenger_count IS 'Yo''lovchilar soni';


--
-- Name: COLUMN orders.has_luggage; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.has_luggage IS 'Pochta bor/yo''q';


--
-- Name: COLUMN orders.luggage_count; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.luggage_count IS 'Pochta soni';


--
-- Name: COLUMN orders.luggage_description; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.luggage_description IS 'Pochta tavsifi';


--
-- Name: COLUMN orders.status; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.status IS 'Buyurtma holati';


--
-- Name: COLUMN orders.commission_amount; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.commission_amount IS 'Komissiya miqdori (so''m)';


--
-- Name: COLUMN orders.created_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.created_at IS 'Buyurtma berilgan vaqt';


--
-- Name: COLUMN orders.accepted_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.accepted_at IS 'Haydovchi qabul qilgan vaqt';


--
-- Name: COLUMN orders.started_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.started_at IS 'Safar boshlangan vaqt';


--
-- Name: COLUMN orders.completed_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.completed_at IS 'Safar yakunlangan vaqt';


--
-- Name: COLUMN orders.cancelled_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.cancelled_at IS 'Bekor qilingan vaqt';


--
-- Name: COLUMN orders.cancellation_reason; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.cancellation_reason IS 'Bekor qilish sababi';


--
-- Name: COLUMN orders.idempotency_key; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.idempotency_key IS 'Idempotency key to prevent duplicates';


--
-- Name: COLUMN orders.auto_confirmed; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.auto_confirmed IS 'Avtomatik tasdiqlangan (2 daqiqadan keyin)';


--
-- Name: COLUMN orders.driver_arrived; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.orders.driver_arrived IS 'Haydovchi yetib keldi';


--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_order_id_seq OWNER TO hamroh_user;

--
-- Name: orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.orders_order_id_seq OWNED BY public.orders.order_id;


--
-- Name: passengers; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.passengers (
    passenger_id bigint NOT NULL,
    user_id bigint NOT NULL,
    full_name character varying(255) NOT NULL,
    gender public.gender_enum NOT NULL,
    age integer NOT NULL,
    phone_number character varying(20) NOT NULL,
    total_trips integer NOT NULL,
    cancellation_count_hour integer NOT NULL,
    last_cancellation_time timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.passengers OWNER TO hamroh_user;

--
-- Name: COLUMN passengers.total_trips; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.passengers.total_trips IS 'Jami safarlar';


--
-- Name: COLUMN passengers.cancellation_count_hour; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.passengers.cancellation_count_hour IS 'Soatdagi bekor qilish soni';


--
-- Name: COLUMN passengers.last_cancellation_time; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.passengers.last_cancellation_time IS 'Oxirgi bekor qilish vaqti';


--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.passengers_passenger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.passengers_passenger_id_seq OWNER TO hamroh_user;

--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.passengers_passenger_id_seq OWNED BY public.passengers.passenger_id;


--
-- Name: routes; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.routes (
    route_id integer NOT NULL,
    from_location character varying(255) NOT NULL,
    to_location character varying(255) NOT NULL,
    from_location_lat numeric(10,8),
    from_location_lon numeric(11,8),
    to_location_lat numeric(10,8),
    to_location_lon numeric(11,8),
    distance_km numeric(5,2),
    fare_amount numeric(12,2),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.routes OWNER TO hamroh_user;

--
-- Name: COLUMN routes.from_location; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.from_location IS 'Qayerdan (Gurlan)';


--
-- Name: COLUMN routes.to_location; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.to_location IS 'Qayerga (Vazir)';


--
-- Name: COLUMN routes.from_location_lat; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.from_location_lat IS 'Qayerdan - Latitude';


--
-- Name: COLUMN routes.from_location_lon; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.from_location_lon IS 'Qayerdan - Longitude';


--
-- Name: COLUMN routes.to_location_lat; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.to_location_lat IS 'Qayerga - Latitude';


--
-- Name: COLUMN routes.to_location_lon; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.to_location_lon IS 'Qayerga - Longitude';


--
-- Name: COLUMN routes.distance_km; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.distance_km IS 'Masofa (km)';


--
-- Name: COLUMN routes.fare_amount; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.fare_amount IS 'Yo''l haqi (so''m)';


--
-- Name: COLUMN routes.is_active; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.routes.is_active IS 'Aktiv marshrut';


--
-- Name: routes_route_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.routes_route_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.routes_route_id_seq OWNER TO hamroh_user;

--
-- Name: routes_route_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.routes_route_id_seq OWNED BY public.routes.route_id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.system_settings (
    setting_key character varying(100) NOT NULL,
    setting_value text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


ALTER TABLE public.system_settings OWNER TO hamroh_user;

--
-- Name: COLUMN system_settings.setting_key; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.system_settings.setting_key IS 'Sozlama kaliti (unique)';


--
-- Name: COLUMN system_settings.setting_value; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.system_settings.setting_value IS 'Sozlama qiymati (JSON yoki text)';


--
-- Name: COLUMN system_settings.description; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.system_settings.description IS 'Sozlama tavsifi';


--
-- Name: transaction_logs; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.transaction_logs (
    log_id integer NOT NULL,
    driver_id bigint NOT NULL,
    order_id integer,
    amount numeric(10,2) NOT NULL,
    type public.transaction_type NOT NULL,
    old_balance numeric(10,2) NOT NULL,
    new_balance numeric(10,2) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.transaction_logs OWNER TO hamroh_user;

--
-- Name: COLUMN transaction_logs.amount; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transaction_logs.amount IS 'Miqdor (musbat/manfiy)';


--
-- Name: COLUMN transaction_logs.old_balance; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transaction_logs.old_balance IS 'Eski balans';


--
-- Name: COLUMN transaction_logs.new_balance; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transaction_logs.new_balance IS 'Yangi balans';


--
-- Name: transaction_logs_log_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.transaction_logs_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_logs_log_id_seq OWNER TO hamroh_user;

--
-- Name: transaction_logs_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.transaction_logs_log_id_seq OWNED BY public.transaction_logs.log_id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.transactions (
    transaction_id integer NOT NULL,
    driver_id bigint NOT NULL,
    admin_id bigint,
    amount numeric(10,2) NOT NULL,
    type public.transaction_type NOT NULL,
    status public.transaction_status NOT NULL,
    receipt_file_id character varying(255),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO hamroh_user;

--
-- Name: COLUMN transactions.admin_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transactions.admin_id IS 'Admin (tasdiqlagan)';


--
-- Name: COLUMN transactions.amount; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transactions.amount IS 'Miqdor (so''m)';


--
-- Name: COLUMN transactions.receipt_file_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transactions.receipt_file_id IS 'Chek file ID (Telegram)';


--
-- Name: COLUMN transactions.description; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transactions.description IS 'Tavsif';


--
-- Name: COLUMN transactions.processed_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.transactions.processed_at IS 'Admin tomonidan ko''rib chiqilgan vaqt';


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.transactions_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transactions_transaction_id_seq OWNER TO hamroh_user;

--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.transactions_transaction_id_seq OWNED BY public.transactions.transaction_id;


--
-- Name: trips; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.trips (
    trip_id integer NOT NULL,
    driver_id bigint NOT NULL,
    route_id integer NOT NULL,
    status public.trip_status NOT NULL,
    total_seats integer NOT NULL,
    available_seats integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    current_lat numeric(10,8),
    current_lon numeric(11,8),
    last_location_update timestamp with time zone
);


ALTER TABLE public.trips OWNER TO hamroh_user;

--
-- Name: COLUMN trips.trip_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.trip_id IS 'Trip ID';


--
-- Name: COLUMN trips.driver_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.driver_id IS 'Haydovchi ID';


--
-- Name: COLUMN trips.route_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.route_id IS 'Marshrut ID';


--
-- Name: COLUMN trips.status; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.status IS 'Trip holati';


--
-- Name: COLUMN trips.total_seats; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.total_seats IS 'Jami o''rindiqlar (mashina sig''imi)';


--
-- Name: COLUMN trips.available_seats; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.available_seats IS 'Bo''sh o''rindiqlar';


--
-- Name: COLUMN trips.created_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.created_at IS 'Trip yaratilgan vaqt';


--
-- Name: COLUMN trips.started_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.started_at IS 'Safar boshlangan vaqt (yo''lga chiqqan)';


--
-- Name: COLUMN trips.completed_at; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.completed_at IS 'Trip yakunlangan vaqt';


--
-- Name: COLUMN trips.current_lat; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.current_lat IS 'Joriy lat (GPS tracking)';


--
-- Name: COLUMN trips.current_lon; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.current_lon IS 'Joriy lon (GPS tracking)';


--
-- Name: COLUMN trips.last_location_update; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.trips.last_location_update IS 'Oxirgi location update vaqti';


--
-- Name: trips_trip_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.trips_trip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trips_trip_id_seq OWNER TO hamroh_user;

--
-- Name: trips_trip_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.trips_trip_id_seq OWNED BY public.trips.trip_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: hamroh_user
--

CREATE TABLE public.users (
    user_id bigint NOT NULL,
    username character varying(255),
    first_name character varying(255) NOT NULL,
    last_name character varying(255),
    phone_number character varying(20) NOT NULL,
    password_hash character varying(255),
    role public.user_role NOT NULL,
    is_blocked boolean NOT NULL,
    registration_date timestamp with time zone DEFAULT now() NOT NULL,
    last_active timestamp with time zone
);


ALTER TABLE public.users OWNER TO hamroh_user;

--
-- Name: COLUMN users.user_id; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.user_id IS 'Telegram user ID';


--
-- Name: COLUMN users.username; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.username IS 'Telegram username (@username)';


--
-- Name: COLUMN users.first_name; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.first_name IS 'Ism';


--
-- Name: COLUMN users.last_name; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.last_name IS 'Familiya';


--
-- Name: COLUMN users.phone_number; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.phone_number IS 'Telefon raqam (+998901234567)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.password_hash IS 'Hashed password (admin/driver uchun)';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.role IS 'Foydalanuvchi roli';


--
-- Name: COLUMN users.is_blocked; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.is_blocked IS 'Bloklangan';


--
-- Name: COLUMN users.registration_date; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.registration_date IS 'Ro''yxatdan o''tgan sana';


--
-- Name: COLUMN users.last_active; Type: COMMENT; Schema: public; Owner: hamroh_user
--

COMMENT ON COLUMN public.users.last_active IS 'Oxirgi faollik';


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: hamroh_user
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO hamroh_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hamroh_user
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: drivers driver_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.drivers ALTER COLUMN driver_id SET DEFAULT nextval('public.drivers_driver_id_seq'::regclass);


--
-- Name: feedbacks feedback_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.feedbacks ALTER COLUMN feedback_id SET DEFAULT nextval('public.feedbacks_feedback_id_seq'::regclass);


--
-- Name: orders order_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders ALTER COLUMN order_id SET DEFAULT nextval('public.orders_order_id_seq'::regclass);


--
-- Name: passengers passenger_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.passengers ALTER COLUMN passenger_id SET DEFAULT nextval('public.passengers_passenger_id_seq'::regclass);


--
-- Name: routes route_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.routes ALTER COLUMN route_id SET DEFAULT nextval('public.routes_route_id_seq'::regclass);


--
-- Name: transaction_logs log_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transaction_logs ALTER COLUMN log_id SET DEFAULT nextval('public.transaction_logs_log_id_seq'::regclass);


--
-- Name: transactions transaction_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transactions ALTER COLUMN transaction_id SET DEFAULT nextval('public.transactions_transaction_id_seq'::regclass);


--
-- Name: trips trip_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.trips ALTER COLUMN trip_id SET DEFAULT nextval('public.trips_trip_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.drivers (driver_id, user_id, full_name, phone_number, car_model, car_color, car_number, license_number, balance, total_trips, rating, ban_count_today, total_ban_count, is_active, is_on_trip, is_blocked, blocked_until, block_reason, current_route_id, available_seats, last_location_lat, last_location_lon, location, created_at, updated_at, last_trip_at) FROM stdin;
1	7315271251	a s	+998200061103	a	a	01A123AA	\N	0.00	1	5.00	0	0	t	t	f	\N	\N	2	1	41.56987800	60.63187800	0101000020E6100000EC87D860E1504E40DE5A26C3F1C84440	2026-01-28 04:36:31.645206+00	2026-02-01 09:15:13.609091+00	2026-02-01 09:15:01.502611+00
\.


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.feedbacks (feedback_id, user_id, resolved_by, message, type, status, admin_reply, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.orders (order_id, passenger_id, driver_id, route_id, trip_id, pickup_location, pickup_lat, pickup_lon, passenger_count, has_luggage, luggage_count, luggage_description, status, commission_amount, created_at, accepted_at, started_at, completed_at, cancelled_at, cancellation_reason, idempotency_key, auto_confirmed, driver_arrived) FROM stdin;
101	2000	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:04:23.05154+00	\N	\N	\N	\N	\N	\N	f	f
106	2001	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:04:23.478186+00	\N	\N	\N	\N	\N	\N	f	f
3	2001	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.165346+00	\N	\N	\N	\N	\N	\N	f	f
251	2000	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:14.974258+00	\N	\N	\N	\N	\N	\N	f	f
5	2011	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.284219+00	\N	\N	\N	\N	\N	\N	f	f
254	2016	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.949027+00	\N	\N	\N	\N	\N	\N	f	f
257	2014	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.421494+00	\N	\N	\N	\N	\N	\N	f	f
262	2013	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.445415+00	\N	\N	\N	\N	\N	\N	f	f
268	2033	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.319046+00	\N	\N	\N	\N	\N	\N	f	f
272	2042	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.391633+00	\N	\N	\N	\N	\N	\N	f	f
275	2045	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.413039+00	\N	\N	\N	\N	\N	\N	f	f
280	2023	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.633296+00	\N	\N	\N	\N	\N	\N	f	f
284	2029	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.704985+00	\N	\N	\N	\N	\N	\N	f	f
170	2006	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:00.672026+00	\N	\N	\N	\N	\N	\N	f	f
15	2008	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.330547+00	\N	\N	\N	\N	\N	\N	f	f
174	2027	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.549191+00	\N	\N	\N	\N	\N	\N	f	f
154	2017	1	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	ACCEPTED	\N	2026-02-01 09:05:01.003007+00	\N	\N	\N	\N	\N	\N	f	f
17	2027	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.335151+00	\N	\N	\N	\N	\N	\N	f	f
287	2034	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.726385+00	\N	\N	\N	\N	\N	\N	f	f
20	2039	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.511632+00	\N	\N	\N	\N	\N	\N	f	f
292	2021	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.039123+00	\N	\N	\N	\N	\N	\N	f	f
294	2030	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.1387+00	\N	\N	\N	\N	\N	\N	f	f
201	2000	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.108495+00	\N	\N	\N	\N	\N	\N	f	f
204	2016	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.904524+00	\N	\N	\N	\N	\N	\N	f	f
207	2014	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.424373+00	\N	\N	\N	\N	\N	\N	f	f
211	2005	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.424232+00	\N	\N	\N	\N	\N	\N	f	f
27	2049	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.560489+00	\N	\N	\N	\N	\N	\N	f	f
218	2034	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.257193+00	\N	\N	\N	\N	\N	\N	f	f
29	2018	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.569032+00	\N	\N	\N	\N	\N	\N	f	f
222	2041	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.361632+00	\N	\N	\N	\N	\N	\N	f	f
230	2024	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.569565+00	\N	\N	\N	\N	\N	\N	f	f
233	2028	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.672816+00	\N	\N	\N	\N	\N	\N	f	f
241	2021	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.880481+00	\N	\N	\N	\N	\N	\N	f	f
248	2039	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.074668+00	\N	\N	\N	\N	\N	\N	f	f
249	2029	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.202194+00	\N	\N	\N	\N	\N	\N	f	f
36	2046	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.600544+00	\N	\N	\N	\N	\N	\N	f	f
301	2	\N	2	\N	Lat: 41.5699, Lon: 60.6319\n 📝 ds\\	41.56987800	60.63187800	1	f	0	\N	CANCELLED	\N	2026-02-01 09:07:54.22996+00	\N	\N	\N	2026-02-01 09:09:58.129989+00	no_driver_available	b4828a17-0887-4330-8f6c-70266ed4e924	f	f
42	2047	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.636097+00	\N	\N	\N	\N	\N	\N	f	f
302	2	1	2	1	Lat: 41.5699, Lon: 60.6319\n 📝 s	41.56987800	60.63187800	1	f	0	\N	COMPLETED	0.00	2026-02-01 09:14:31.243223+00	2026-02-01 09:14:38.32602+00	2026-02-01 09:14:50.628033+00	2026-02-01 09:15:01.502611+00	\N	\N	a273d6d1-eed5-45d6-aada-353c02ff8eab	f	f
46	2020	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.660046+00	\N	\N	\N	\N	\N	\N	f	f
47	2048	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.661222+00	\N	\N	\N	\N	\N	\N	f	f
48	2021	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:01:22.661806+00	\N	\N	\N	\N	\N	\N	f	f
56	2019	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:57.805143+00	\N	\N	\N	\N	\N	\N	f	f
58	2010	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:57.316393+00	\N	\N	\N	\N	\N	\N	f	f
64	2022	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.350937+00	\N	\N	\N	\N	\N	\N	f	f
63	2014	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:57.365602+00	\N	\N	\N	\N	\N	\N	f	f
252	2001	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.404635+00	\N	\N	\N	\N	\N	\N	f	f
258	2006	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.42456+00	\N	\N	\N	\N	\N	\N	f	f
263	2012	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.424596+00	\N	\N	\N	\N	\N	\N	f	f
267	2032	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.317987+00	\N	\N	\N	\N	\N	\N	f	f
279	2022	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.633124+00	\N	\N	\N	\N	\N	\N	f	f
84	2042	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.570191+00	\N	\N	\N	\N	\N	\N	f	f
89	2048	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.597339+00	\N	\N	\N	\N	\N	\N	f	f
96	2033	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.773906+00	\N	\N	\N	\N	\N	\N	f	f
158	2020	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.300281+00	\N	\N	\N	\N	\N	\N	f	f
177	2030	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.575888+00	\N	\N	\N	\N	\N	\N	f	f
191	2021	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.686904+00	\N	\N	\N	\N	\N	\N	f	f
202	2004	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.456503+00	\N	\N	\N	\N	\N	\N	f	f
208	2007	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.455962+00	\N	\N	\N	\N	\N	\N	f	f
213	2003	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.357632+00	\N	\N	\N	\N	\N	\N	f	f
217	2032	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.237433+00	\N	\N	\N	\N	\N	\N	f	f
224	2046	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.413053+00	\N	\N	\N	\N	\N	\N	f	f
229	2022	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.55294+00	\N	\N	\N	\N	\N	\N	f	f
236	2035	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.727626+00	\N	\N	\N	\N	\N	\N	f	f
240	2019	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.866939+00	\N	\N	\N	\N	\N	\N	f	f
245	2043	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.039235+00	\N	\N	\N	\N	\N	\N	f	f
250	2018	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.224779+00	\N	\N	\N	\N	\N	\N	f	f
75	2030	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.449304+00	\N	\N	\N	\N	\N	\N	f	f
253	2004	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.422082+00	\N	\N	\N	\N	\N	\N	f	f
259	2008	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.432266+00	\N	\N	\N	\N	\N	\N	f	f
264	2005	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.421862+00	\N	\N	\N	\N	\N	\N	f	f
123	2027	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:04:24.42416+00	\N	\N	\N	\N	\N	\N	f	f
269	2036	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.338725+00	\N	\N	\N	\N	\N	\N	f	f
274	2046	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.413241+00	\N	\N	\N	\N	\N	\N	f	f
276	2015	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.439789+00	\N	\N	\N	\N	\N	\N	f	f
282	2027	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.653073+00	\N	\N	\N	\N	\N	\N	f	f
286	2035	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.726542+00	\N	\N	\N	\N	\N	\N	f	f
290	2018	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.968417+00	\N	\N	\N	\N	\N	\N	f	f
291	2024	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.039427+00	\N	\N	\N	\N	\N	\N	f	f
297	2019	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.241241+00	\N	\N	\N	\N	\N	\N	f	f
176	2001	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:00.66628+00	\N	\N	\N	\N	\N	\N	f	f
180	2034	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.61865+00	\N	\N	\N	\N	\N	\N	f	f
298	2041	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.41262+00	\N	\N	\N	\N	\N	\N	f	f
300	2049	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.460511+00	\N	\N	\N	\N	\N	\N	f	f
187	2046	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.660465+00	\N	\N	\N	\N	\N	\N	f	f
203	2011	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.466624+00	\N	\N	\N	\N	\N	\N	f	f
209	2012	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.458392+00	\N	\N	\N	\N	\N	\N	f	f
214	2008	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.45717+00	\N	\N	\N	\N	\N	\N	f	f
219	2036	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.313124+00	\N	\N	\N	\N	\N	\N	f	f
221	2040	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.359229+00	\N	\N	\N	\N	\N	\N	f	f
226	2017	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.460804+00	\N	\N	\N	\N	\N	\N	f	f
232	2027	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.670429+00	\N	\N	\N	\N	\N	\N	f	f
235	2033	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.724778+00	\N	\N	\N	\N	\N	\N	f	f
238	2045	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.776791+00	\N	\N	\N	\N	\N	\N	f	f
242	2026	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.981031+00	\N	\N	\N	\N	\N	\N	f	f
244	2042	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.038453+00	\N	\N	\N	\N	\N	\N	f	f
70	2027	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.423901+00	\N	\N	\N	\N	\N	\N	f	f
255	2011	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.404755+00	\N	\N	\N	\N	\N	\N	f	f
261	2007	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.422266+00	\N	\N	\N	\N	\N	\N	f	f
265	2010	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.462267+00	\N	\N	\N	\N	\N	\N	f	f
270	2037	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.342817+00	\N	\N	\N	\N	\N	\N	f	f
273	2044	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.407899+00	\N	\N	\N	\N	\N	\N	f	f
277	2017	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.442319+00	\N	\N	\N	\N	\N	\N	f	f
281	2026	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.652788+00	\N	\N	\N	\N	\N	\N	f	f
285	2031	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.722023+00	\N	\N	\N	\N	\N	\N	f	f
288	2043	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.754962+00	\N	\N	\N	\N	\N	\N	f	f
293	2025	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.039507+00	\N	\N	\N	\N	\N	\N	f	f
295	2039	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.170859+00	\N	\N	\N	\N	\N	\N	f	f
149	2021	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:04:24.5257+00	\N	\N	\N	\N	\N	\N	f	f
299	2038	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.412509+00	\N	\N	\N	\N	\N	\N	f	f
182	2037	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.627328+00	\N	\N	\N	\N	\N	\N	f	f
192	2032	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.705139+00	\N	\N	\N	\N	\N	\N	f	f
205	2001	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.423983+00	\N	\N	\N	\N	\N	\N	f	f
210	2002	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.459008+00	\N	\N	\N	\N	\N	\N	f	f
215	2010	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.500442+00	\N	\N	\N	\N	\N	\N	f	f
223	2044	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.396347+00	\N	\N	\N	\N	\N	\N	f	f
227	2015	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.460149+00	\N	\N	\N	\N	\N	\N	f	f
234	2030	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.709132+00	\N	\N	\N	\N	\N	\N	f	f
243	2031	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.020764+00	\N	\N	\N	\N	\N	\N	f	f
256	2002	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.404749+00	\N	\N	\N	\N	\N	\N	f	f
72	2007	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:57.381287+00	\N	\N	\N	\N	\N	\N	f	f
73	2031	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.465043+00	\N	\N	\N	\N	\N	\N	f	f
260	2003	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.424675+00	\N	\N	\N	\N	\N	\N	f	f
266	2009	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:15.404168+00	\N	\N	\N	\N	\N	\N	f	f
271	2040	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.360418+00	\N	\N	\N	\N	\N	\N	f	f
278	2020	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.46009+00	\N	\N	\N	\N	\N	\N	f	f
283	2028	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.671529+00	\N	\N	\N	\N	\N	\N	f	f
289	2048	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:16.773036+00	\N	\N	\N	\N	\N	\N	f	f
88	2047	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:02:58.596536+00	\N	\N	\N	\N	\N	\N	f	f
296	2047	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:06:17.187843+00	\N	\N	\N	\N	\N	\N	f	f
168	2025	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.539095+00	\N	\N	\N	\N	\N	\N	f	f
169	2013	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:00.670829+00	\N	\N	\N	\N	\N	\N	f	f
194	2039	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:01.747633+00	\N	\N	\N	\N	\N	\N	f	f
206	2006	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.424061+00	\N	\N	\N	\N	\N	\N	f	f
212	2013	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.460699+00	\N	\N	\N	\N	\N	\N	f	f
216	2009	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:44.456711+00	\N	\N	\N	\N	\N	\N	f	f
220	2038	\N	5	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.34834+00	\N	\N	\N	\N	\N	\N	f	f
225	2047	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.413511+00	\N	\N	\N	\N	\N	\N	f	f
228	2020	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.476706+00	\N	\N	\N	\N	\N	\N	f	f
231	2025	\N	3	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.660837+00	\N	\N	\N	\N	\N	\N	f	f
237	2037	\N	2	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.727844+00	\N	\N	\N	\N	\N	\N	f	f
239	2049	\N	4	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:45.788951+00	\N	\N	\N	\N	\N	\N	f	f
246	2048	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.039804+00	\N	\N	\N	\N	\N	\N	f	f
247	2023	\N	1	\N	Toshkent Docker Test	41.00000000	69.00000000	1	f	0	\N	PENDING	\N	2026-02-01 09:05:46.066718+00	\N	\N	\N	\N	\N	\N	f	f
\.


--
-- Data for Name: passengers; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.passengers (passenger_id, user_id, full_name, gender, age, phone_number, total_trips, cancellation_count_hour, last_cancellation_time, created_at) FROM stdin;
1	11111	Test Passenger	MALE	25	+998901234567	0	0	\N	2026-01-28 04:29:41.403427+00
2000	2000	Pass 2000	MALE	25	998901232000	0	0	\N	2026-02-01 09:01:21.235746+00
2002	2002	Pass 2002	MALE	25	998901232002	0	0	\N	2026-02-01 09:01:21.489439+00
2001	2001	Pass 2001	MALE	25	998901232001	0	0	\N	2026-02-01 09:01:21.490656+00
2013	2013	Pass 2013	MALE	25	998901232013	0	0	\N	2026-02-01 09:01:21.492533+00
2007	2007	Pass 2007	MALE	25	998901232007	0	0	\N	2026-02-01 09:01:21.580773+00
2004	2004	Pass 2004	MALE	25	998901232004	0	0	\N	2026-02-01 09:01:21.491493+00
2003	2003	Pass 2003	MALE	25	998901232003	0	0	\N	2026-02-01 09:01:21.487464+00
2010	2010	Pass 2010	MALE	25	998901232010	0	0	\N	2026-02-01 09:01:21.575013+00
2014	2014	Pass 2014	MALE	25	998901232014	0	0	\N	2026-02-01 09:01:21.630674+00
2005	2005	Pass 2005	MALE	25	998901232005	0	0	\N	2026-02-01 09:01:21.49355+00
2012	2012	Pass 2012	MALE	25	998901232012	0	0	\N	2026-02-01 09:01:21.573421+00
2006	2006	Pass 2006	MALE	25	998901232006	0	0	\N	2026-02-01 09:01:21.573201+00
2011	2011	Pass 2011	MALE	25	998901232011	0	0	\N	2026-02-01 09:01:21.573248+00
2008	2008	Pass 2008	MALE	25	998901232008	0	0	\N	2026-02-01 09:01:21.485935+00
2009	2009	Pass 2009	MALE	25	998901232009	0	0	\N	2026-02-01 09:01:21.574203+00
2026	2026	Pass 2026	MALE	25	998901232026	0	0	\N	2026-02-01 09:01:22.278512+00
2027	2027	Pass 2027	MALE	25	998901232027	0	0	\N	2026-02-01 09:01:22.282854+00
2032	2032	Pass 2032	MALE	25	998901232032	0	0	\N	2026-02-01 09:01:22.327645+00
2038	2038	Pass 2038	MALE	25	998901232038	0	0	\N	2026-02-01 09:01:22.459859+00
2039	2039	Pass 2039	MALE	25	998901232039	0	0	\N	2026-02-01 09:01:22.467417+00
2040	2040	Pass 2040	MALE	25	998901232040	0	0	\N	2026-02-01 09:01:22.477215+00
2041	2041	Pass 2041	MALE	25	998901232041	0	0	\N	2026-02-01 09:01:22.483814+00
2042	2042	Pass 2042	MALE	25	998901232042	0	0	\N	2026-02-01 09:01:22.485682+00
2044	2044	Pass 2044	MALE	25	998901232044	0	0	\N	2026-02-01 09:01:22.492612+00
2043	2043	Pass 2043	MALE	25	998901232043	0	0	\N	2026-02-01 09:01:22.498268+00
2045	2045	Pass 2045	MALE	25	998901232045	0	0	\N	2026-02-01 09:01:22.499428+00
2049	2049	Pass 2049	MALE	25	998901232049	0	0	\N	2026-02-01 09:01:22.522463+00
2016	2016	Pass 2016	MALE	25	998901232016	0	0	\N	2026-02-01 09:01:22.526424+00
2018	2018	Pass 2018	MALE	25	998901232018	0	0	\N	2026-02-01 09:01:22.527671+00
2030	2030	Pass 2030	MALE	25	998901232030	0	0	\N	2026-02-01 09:01:22.561621+00
2025	2025	Pass 2025	MALE	25	998901232025	0	0	\N	2026-02-01 09:01:22.559361+00
2028	2028	Pass 2028	MALE	25	998901232028	0	0	\N	2026-02-01 09:01:22.559995+00
2033	2033	Pass 2033	MALE	25	998901232033	0	0	\N	2026-02-01 09:01:22.56825+00
2036	2036	Pass 2036	MALE	25	998901232036	0	0	\N	2026-02-01 09:01:22.571979+00
2035	2035	Pass 2035	MALE	25	998901232035	0	0	\N	2026-02-01 09:01:22.571257+00
2046	2046	Pass 2046	MALE	25	998901232046	0	0	\N	2026-02-01 09:01:22.585366+00
2015	2015	Pass 2015	MALE	25	998901232015	0	0	\N	2026-02-01 09:01:22.592333+00
2024	2024	Pass 2024	MALE	25	998901232024	0	0	\N	2026-02-01 09:01:22.603004+00
2029	2029	Pass 2029	MALE	25	998901232029	0	0	\N	2026-02-01 09:01:22.605721+00
2031	2031	Pass 2031	MALE	25	998901232031	0	0	\N	2026-02-01 09:01:22.606654+00
2034	2034	Pass 2034	MALE	25	998901232034	0	0	\N	2026-02-01 09:01:22.609316+00
2037	2037	Pass 2037	MALE	25	998901232037	0	0	\N	2026-02-01 09:01:22.609499+00
2047	2047	Pass 2047	MALE	25	998901232047	0	0	\N	2026-02-01 09:01:22.611556+00
2022	2022	Pass 2022	MALE	25	998901232022	0	0	\N	2026-02-01 09:01:22.635061+00
2023	2023	Pass 2023	MALE	25	998901232023	0	0	\N	2026-02-01 09:01:22.635188+00
2020	2020	Pass 2020	MALE	25	998901232020	0	0	\N	2026-02-01 09:01:22.646711+00
2048	2048	Pass 2048	MALE	25	998901232048	0	0	\N	2026-02-01 09:01:22.648404+00
2021	2021	Pass 2021	MALE	25	998901232021	0	0	\N	2026-02-01 09:01:22.648342+00
2017	2017	Pass 2017	MALE	25	998901232017	0	0	\N	2026-02-01 09:01:22.649914+00
2019	2019	Pass 2019	MALE	25	998901232019	0	0	\N	2026-02-01 09:01:22.649756+00
2	5146421024	a s	MALE	19	+998935580311	1	0	\N	2026-01-28 04:35:47.063278+00
\.


--
-- Data for Name: routes; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.routes (route_id, from_location, to_location, from_location_lat, from_location_lon, to_location_lat, to_location_lon, distance_km, fare_amount, is_active, created_at) FROM stdin;
1	Test Route	Test Destination	\N	\N	\N	\N	10.00	5000.00	t	2026-01-28 04:29:41.681387+00
2	Start 2	End 2	\N	\N	\N	\N	10.00	5000.00	t	2026-02-01 09:05:43.857467+00
3	Start 3	End 3	\N	\N	\N	\N	10.00	5000.00	t	2026-02-01 09:05:43.857467+00
4	Start 4	End 4	\N	\N	\N	\N	10.00	5000.00	t	2026-02-01 09:05:43.857467+00
5	Start 5	End 5	\N	\N	\N	\N	10.00	5000.00	t	2026-02-01 09:05:43.857467+00
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.system_settings (setting_key, setting_value, description, created_at, updated_at) FROM stdin;
auto_start_trip_delay_seconds	180	Trip avtomatik boshlash kechikishi (soniya)	2026-01-28 04:48:42.982791+00	\N
bot_is_free	true	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:58.970249+00
commission_amount	0	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.024681+00
ban_percentage_threshold	50	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.065277+00
ban_count_threshold	5	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.074716+00
max_driver_change_per_hour	3	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.08367+00
max_pickup_distance_km	50	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.093761+00
auto_confirm_delay_seconds	120	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.102592+00
sms_rate_limit_per_day	5	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.111961+00
sms_rate_limit_per_hour	3	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.122487+00
max_driver_rejects_per_day	50	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.131075+00
auto_complete_trip_seconds	600	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.139082+00
auto_reject_order_seconds	120	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.147035+00
auto_confirm_trip_seconds	1800	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.155128+00
driver_matching_timeout_seconds	300	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.163227+00
driver_matching_max_retries	5	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.172148+00
driver_matching_retry_delay_seconds	30	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.179943+00
order_lock_timeout_seconds	60	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.187321+00
generic_lock_timeout_seconds	10	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.19525+00
state_ttl_seconds	3600	\N	2026-01-28 04:48:42.982791+00	2026-01-28 05:00:59.203179+00
\.


--
-- Data for Name: transaction_logs; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.transaction_logs (log_id, driver_id, order_id, amount, type, old_balance, new_balance, description, created_at) FROM stdin;
1	1	302	0.00	COMMISSION	0.00	0.00	Safar #302 uchun komissiya	2026-02-01 09:14:38.32602+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.transactions (transaction_id, driver_id, admin_id, amount, type, status, receipt_file_id, description, created_at, processed_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.trips (trip_id, driver_id, route_id, status, total_seats, available_seats, created_at, started_at, completed_at, current_lat, current_lon, last_location_update) FROM stdin;
1	1	2	ACTIVE	1	0	2026-02-01 09:14:38.32602+00	2026-02-01 09:14:50.628033+00	\N	\N	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hamroh_user
--

COPY public.users (user_id, username, first_name, last_name, phone_number, password_hash, role, is_blocked, registration_date, last_active) FROM stdin;
11111	\N	Test	\N	+998901234567	\N	PASSENGER	f	2026-01-28 04:29:41.403427+00	\N
999999999	admin	Admin	\N	+998999999999	$2b$12$fELbVR5XJ6sut.yUbqALg.ybfsSglDP5doG/68LjgO3dlH3FdDxc6	GLAVNI_ADMIN	f	2026-01-28 05:00:12.486934+00	2026-01-28 05:00:40.66031+00
2000	\N	Pass 2000	\N	998901232000	\N	PASSENGER	f	2026-02-01 09:01:21.235746+00	\N
2002	\N	Pass 2002	\N	998901232002	\N	PASSENGER	f	2026-02-01 09:01:21.489439+00	\N
2001	\N	Pass 2001	\N	998901232001	\N	PASSENGER	f	2026-02-01 09:01:21.490656+00	\N
2013	\N	Pass 2013	\N	998901232013	\N	PASSENGER	f	2026-02-01 09:01:21.492533+00	\N
2007	\N	Pass 2007	\N	998901232007	\N	PASSENGER	f	2026-02-01 09:01:21.580773+00	\N
2004	\N	Pass 2004	\N	998901232004	\N	PASSENGER	f	2026-02-01 09:01:21.491493+00	\N
2003	\N	Pass 2003	\N	998901232003	\N	PASSENGER	f	2026-02-01 09:01:21.487464+00	\N
2010	\N	Pass 2010	\N	998901232010	\N	PASSENGER	f	2026-02-01 09:01:21.575013+00	\N
2005	\N	Pass 2005	\N	998901232005	\N	PASSENGER	f	2026-02-01 09:01:21.49355+00	\N
2014	\N	Pass 2014	\N	998901232014	\N	PASSENGER	f	2026-02-01 09:01:21.630674+00	\N
2011	\N	Pass 2011	\N	998901232011	\N	PASSENGER	f	2026-02-01 09:01:21.573248+00	\N
2012	\N	Pass 2012	\N	998901232012	\N	PASSENGER	f	2026-02-01 09:01:21.573421+00	\N
2006	\N	Pass 2006	\N	998901232006	\N	PASSENGER	f	2026-02-01 09:01:21.573201+00	\N
2008	\N	Pass 2008	\N	998901232008	\N	PASSENGER	f	2026-02-01 09:01:21.485935+00	\N
2009	\N	Pass 2009	\N	998901232009	\N	PASSENGER	f	2026-02-01 09:01:21.574203+00	\N
2026	\N	Pass 2026	\N	998901232026	\N	PASSENGER	f	2026-02-01 09:01:22.278512+00	\N
2027	\N	Pass 2027	\N	998901232027	\N	PASSENGER	f	2026-02-01 09:01:22.282854+00	\N
2032	\N	Pass 2032	\N	998901232032	\N	PASSENGER	f	2026-02-01 09:01:22.327645+00	\N
2038	\N	Pass 2038	\N	998901232038	\N	PASSENGER	f	2026-02-01 09:01:22.459859+00	\N
2039	\N	Pass 2039	\N	998901232039	\N	PASSENGER	f	2026-02-01 09:01:22.467417+00	\N
2040	\N	Pass 2040	\N	998901232040	\N	PASSENGER	f	2026-02-01 09:01:22.477215+00	\N
2041	\N	Pass 2041	\N	998901232041	\N	PASSENGER	f	2026-02-01 09:01:22.483814+00	\N
2042	\N	Pass 2042	\N	998901232042	\N	PASSENGER	f	2026-02-01 09:01:22.485682+00	\N
2043	\N	Pass 2043	\N	998901232043	\N	PASSENGER	f	2026-02-01 09:01:22.498268+00	\N
2044	\N	Pass 2044	\N	998901232044	\N	PASSENGER	f	2026-02-01 09:01:22.492612+00	\N
2045	\N	Pass 2045	\N	998901232045	\N	PASSENGER	f	2026-02-01 09:01:22.499428+00	\N
2049	\N	Pass 2049	\N	998901232049	\N	PASSENGER	f	2026-02-01 09:01:22.522463+00	\N
2016	\N	Pass 2016	\N	998901232016	\N	PASSENGER	f	2026-02-01 09:01:22.526424+00	\N
2018	\N	Pass 2018	\N	998901232018	\N	PASSENGER	f	2026-02-01 09:01:22.527671+00	\N
2025	\N	Pass 2025	\N	998901232025	\N	PASSENGER	f	2026-02-01 09:01:22.559361+00	\N
2028	\N	Pass 2028	\N	998901232028	\N	PASSENGER	f	2026-02-01 09:01:22.559995+00	\N
2030	\N	Pass 2030	\N	998901232030	\N	PASSENGER	f	2026-02-01 09:01:22.561621+00	\N
2033	\N	Pass 2033	\N	998901232033	\N	PASSENGER	f	2026-02-01 09:01:22.56825+00	\N
2036	\N	Pass 2036	\N	998901232036	\N	PASSENGER	f	2026-02-01 09:01:22.571979+00	\N
2035	\N	Pass 2035	\N	998901232035	\N	PASSENGER	f	2026-02-01 09:01:22.571257+00	\N
2046	\N	Pass 2046	\N	998901232046	\N	PASSENGER	f	2026-02-01 09:01:22.585366+00	\N
2015	\N	Pass 2015	\N	998901232015	\N	PASSENGER	f	2026-02-01 09:01:22.592333+00	\N
2024	\N	Pass 2024	\N	998901232024	\N	PASSENGER	f	2026-02-01 09:01:22.603004+00	\N
2029	\N	Pass 2029	\N	998901232029	\N	PASSENGER	f	2026-02-01 09:01:22.605721+00	\N
2031	\N	Pass 2031	\N	998901232031	\N	PASSENGER	f	2026-02-01 09:01:22.606654+00	\N
2034	\N	Pass 2034	\N	998901232034	\N	PASSENGER	f	2026-02-01 09:01:22.609316+00	\N
2037	\N	Pass 2037	\N	998901232037	\N	PASSENGER	f	2026-02-01 09:01:22.609499+00	\N
2047	\N	Pass 2047	\N	998901232047	\N	PASSENGER	f	2026-02-01 09:01:22.611556+00	\N
2022	\N	Pass 2022	\N	998901232022	\N	PASSENGER	f	2026-02-01 09:01:22.635061+00	\N
2023	\N	Pass 2023	\N	998901232023	\N	PASSENGER	f	2026-02-01 09:01:22.635188+00	\N
2020	\N	Pass 2020	\N	998901232020	\N	PASSENGER	f	2026-02-01 09:01:22.646711+00	\N
2021	\N	Pass 2021	\N	998901232021	\N	PASSENGER	f	2026-02-01 09:01:22.648342+00	\N
2048	\N	Pass 2048	\N	998901232048	\N	PASSENGER	f	2026-02-01 09:01:22.648404+00	\N
2017	\N	Pass 2017	\N	998901232017	\N	PASSENGER	f	2026-02-01 09:01:22.649914+00	\N
2019	\N	Pass 2019	\N	998901232019	\N	PASSENGER	f	2026-02-01 09:01:22.649756+00	\N
7315271251	Ice_z_gen	print(" ")	\N	+998200061103	\N	DRIVER	f	2026-01-28 04:36:31.645206+00	2026-02-01 09:13:27.645353+00
5146421024	Bakhromdev	Baxrom	Reyimberganov	+998935580311	\N	PASSENGER	f	2026-01-28 04:35:47.063278+00	2026-02-01 09:14:17.817961+00
\.


--
-- Name: drivers_driver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.drivers_driver_id_seq', 1, true);


--
-- Name: feedbacks_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.feedbacks_feedback_id_seq', 1, false);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 302, true);


--
-- Name: passengers_passenger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.passengers_passenger_id_seq', 2, true);


--
-- Name: routes_route_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.routes_route_id_seq', 1, false);


--
-- Name: transaction_logs_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.transaction_logs_log_id_seq', 1, true);


--
-- Name: transactions_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.transactions_transaction_id_seq', 1, false);


--
-- Name: trips_trip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.trips_trip_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hamroh_user
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, false);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (driver_id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (feedback_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: passengers passengers_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT passengers_pkey PRIMARY KEY (passenger_id);


--
-- Name: routes routes_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.routes
    ADD CONSTRAINT routes_pkey PRIMARY KEY (route_id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (setting_key);


--
-- Name: transaction_logs transaction_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transaction_logs
    ADD CONSTRAINT transaction_logs_pkey PRIMARY KEY (log_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (trip_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: idx_drivers_active_blocked; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_drivers_active_blocked ON public.drivers USING btree (is_active, is_blocked);


--
-- Name: idx_drivers_active_route; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_drivers_active_route ON public.drivers USING btree (is_active, current_route_id);


--
-- Name: idx_drivers_location; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_drivers_location ON public.drivers USING gist (location);


--
-- Name: idx_drivers_route_seats; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_drivers_route_seats ON public.drivers USING btree (current_route_id, available_seats);


--
-- Name: idx_orders_driver_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_orders_driver_status ON public.orders USING btree (driver_id, status);


--
-- Name: idx_orders_passenger_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_orders_passenger_status ON public.orders USING btree (passenger_id, status);


--
-- Name: idx_orders_route_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_orders_route_status ON public.orders USING btree (route_id, status);


--
-- Name: idx_orders_status_created; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_orders_status_created ON public.orders USING btree (status, created_at);


--
-- Name: idx_routes_active; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_routes_active ON public.routes USING btree (is_active);


--
-- Name: idx_routes_unique; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX idx_routes_unique ON public.routes USING btree (from_location, to_location);


--
-- Name: idx_settings_key; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_settings_key ON public.system_settings USING btree (setting_key);


--
-- Name: idx_transaction_logs_driver_created; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_transaction_logs_driver_created ON public.transaction_logs USING btree (driver_id, created_at);


--
-- Name: idx_transactions_driver_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_transactions_driver_status ON public.transactions USING btree (driver_id, status);


--
-- Name: idx_transactions_status_created; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_transactions_status_created ON public.transactions USING btree (status, created_at);


--
-- Name: idx_trips_created; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_trips_created ON public.trips USING btree (created_at);


--
-- Name: idx_trips_driver_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_trips_driver_status ON public.trips USING btree (driver_id, status);


--
-- Name: idx_trips_route_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_trips_route_status ON public.trips USING btree (route_id, status);


--
-- Name: idx_users_role_blocked; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX idx_users_role_blocked ON public.users USING btree (role, is_blocked);


--
-- Name: ix_drivers_car_number; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX ix_drivers_car_number ON public.drivers USING btree (car_number);


--
-- Name: ix_drivers_current_route_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_drivers_current_route_id ON public.drivers USING btree (current_route_id);


--
-- Name: ix_drivers_is_active; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_drivers_is_active ON public.drivers USING btree (is_active);


--
-- Name: ix_drivers_is_blocked; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_drivers_is_blocked ON public.drivers USING btree (is_blocked);


--
-- Name: ix_drivers_is_on_trip; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_drivers_is_on_trip ON public.drivers USING btree (is_on_trip);


--
-- Name: ix_drivers_phone_number; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_drivers_phone_number ON public.drivers USING btree (phone_number);


--
-- Name: ix_drivers_user_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX ix_drivers_user_id ON public.drivers USING btree (user_id);


--
-- Name: ix_feedbacks_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_feedbacks_status ON public.feedbacks USING btree (status);


--
-- Name: ix_feedbacks_user_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_feedbacks_user_id ON public.feedbacks USING btree (user_id);


--
-- Name: ix_orders_created_at; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: ix_orders_driver_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_driver_id ON public.orders USING btree (driver_id);


--
-- Name: ix_orders_idempotency_key; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX ix_orders_idempotency_key ON public.orders USING btree (idempotency_key);


--
-- Name: ix_orders_passenger_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_passenger_id ON public.orders USING btree (passenger_id);


--
-- Name: ix_orders_route_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_route_id ON public.orders USING btree (route_id);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_status ON public.orders USING btree (status);


--
-- Name: ix_orders_trip_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_orders_trip_id ON public.orders USING btree (trip_id);


--
-- Name: ix_passengers_phone_number; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_passengers_phone_number ON public.passengers USING btree (phone_number);


--
-- Name: ix_passengers_user_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX ix_passengers_user_id ON public.passengers USING btree (user_id);


--
-- Name: ix_routes_is_active; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_routes_is_active ON public.routes USING btree (is_active);


--
-- Name: ix_transaction_logs_created_at; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transaction_logs_created_at ON public.transaction_logs USING btree (created_at);


--
-- Name: ix_transaction_logs_driver_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transaction_logs_driver_id ON public.transaction_logs USING btree (driver_id);


--
-- Name: ix_transaction_logs_order_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transaction_logs_order_id ON public.transaction_logs USING btree (order_id);


--
-- Name: ix_transactions_admin_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transactions_admin_id ON public.transactions USING btree (admin_id);


--
-- Name: ix_transactions_created_at; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transactions_created_at ON public.transactions USING btree (created_at);


--
-- Name: ix_transactions_driver_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transactions_driver_id ON public.transactions USING btree (driver_id);


--
-- Name: ix_transactions_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transactions_status ON public.transactions USING btree (status);


--
-- Name: ix_transactions_type; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_transactions_type ON public.transactions USING btree (type);


--
-- Name: ix_trips_driver_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_trips_driver_id ON public.trips USING btree (driver_id);


--
-- Name: ix_trips_route_id; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_trips_route_id ON public.trips USING btree (route_id);


--
-- Name: ix_trips_status; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_trips_status ON public.trips USING btree (status);


--
-- Name: ix_users_is_blocked; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_users_is_blocked ON public.users USING btree (is_blocked);


--
-- Name: ix_users_phone_number; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE UNIQUE INDEX ix_users_phone_number ON public.users USING btree (phone_number);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: hamroh_user
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: drivers drivers_current_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_current_route_id_fkey FOREIGN KEY (current_route_id) REFERENCES public.routes(route_id) ON DELETE SET NULL;


--
-- Name: drivers drivers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: feedbacks feedbacks_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: feedbacks feedbacks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: orders orders_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(driver_id) ON DELETE SET NULL;


--
-- Name: orders orders_passenger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_passenger_id_fkey FOREIGN KEY (passenger_id) REFERENCES public.passengers(passenger_id) ON DELETE CASCADE;


--
-- Name: orders orders_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.routes(route_id) ON DELETE CASCADE;


--
-- Name: orders orders_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(trip_id) ON DELETE SET NULL;


--
-- Name: passengers passengers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.passengers
    ADD CONSTRAINT passengers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: transaction_logs transaction_logs_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transaction_logs
    ADD CONSTRAINT transaction_logs_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(driver_id) ON DELETE CASCADE;


--
-- Name: transaction_logs transaction_logs_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transaction_logs
    ADD CONSTRAINT transaction_logs_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE SET NULL;


--
-- Name: transactions transactions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: transactions transactions_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(driver_id) ON DELETE CASCADE;


--
-- Name: trips trips_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(driver_id) ON DELETE CASCADE;


--
-- Name: trips trips_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hamroh_user
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.routes(route_id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hamroh_user
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

